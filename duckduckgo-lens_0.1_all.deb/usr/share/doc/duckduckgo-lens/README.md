duckduckgo-lens
===============

A DuckDuckGo Lens for ubuntu's Unity